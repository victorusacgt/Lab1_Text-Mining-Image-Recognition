# -*- coding: utf-8 -*-
"""
Created on Sun Jul 28 20:13:55 2019

@author: Victor
19005180
"""
#19005180
import cv2
import sys

sel = 30 #Aca se selecciona que color va a ser

def imagen(img_in, col):
    img = cv2.imread(img_in)
    if (col == 1): #Azul
        img[:,:,2] = 0 # 
        img[:,:,1] = 0
        cv2.imwrite("resultado.jpg", img) 
        cv2.imshow("Img_Mostrada", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        sys.exit()
    elif (col == 2): #Verde
        img[:,:,2] = 0
        img[:,:,0] = 0
        cv2.imwrite("resultado.jpg", img) 
        cv2.imshow("Img_Mostrada", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        sys.exit()
    elif (col == 3): #Rojo
        img[:,:,0] = 0
        img[:,:,1] = 0
        cv2.imwrite("resultado.jpg", img) 
        cv2.imshow("Img_Mostrada", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        sys.exit() 
    elif (col == 10): #Amarillo
        img[:,:,0] = 0
        cv2.imwrite("resultado.jpg", img) 
        cv2.imshow("Img_Mostrada", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        sys.exit()
    elif (col == 20): #aqua
        img[:,:,2] = 0
        cv2.imwrite("resultado.jpg", img) 
        cv2.imshow("Img_Mostrada", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        sys.exit()
    elif (col == 30): #fusia
        img[:,:,1] = 0
        cv2.imwrite("resultado.jpg", img) 
        cv2.imshow("Img_Mostrada", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        sys.exit()
    else:
        print("Favor elegir valores 1,2,3,10,20,30")
    
imagen("img.jpg", sel)
